
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    Connection con;
    public Connection getConetion(){
        try {
             String url = "jdbc:mysql://localhost:3306/sistemaventa?useTimezone=true&serverTimezone=UTC";
             con = DriverManager.getConnection(url, "root", "");
             return con;
        } catch (SQLException e) {
            System. out.println (e.toString () );    
        }    
        return null;  
    }   
}
